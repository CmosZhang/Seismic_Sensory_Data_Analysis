function genericcallback (t, f, x)
  fprintf('%3d  %0.5g \n', t, f);
  