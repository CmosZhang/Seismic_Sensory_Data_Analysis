function PlotCDF( CDF, sampleRate, lineName)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

str = {};
sz = length(CDF(1, :));
figure; 
markers = ['-o'; '-+'; '-*'; '-s'; '-d'; '->'; '-p'; '-h'];
for i = 1 : size(CDF, 1)
    plot((1:sz)/sz * 100, CDF(i, :), markers(i, :) ,'MarkerSize', 4);hold on; 
    if i <= length(sampleRate)
        str = [str; ['Noise-free ', num2str(sampleRate(i)*100), '% sampling rate']];
    end
end
str = [str; {lineName}];
grid on; title('Empirical CDF'); xlabel('Top portion of singular value %'); ylabel('CDF');
legend(str);
end

