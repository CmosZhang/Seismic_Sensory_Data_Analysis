function [ out ] = dipEnhance(img, filtParam)
    %% ��ʼ��������ֵ����ǿͼ���Ե�� 
    [imgRow, imgCol] = size(img);
    aver = mean(img(:));
    averImg = aver * ones(imgRow, imgCol) / 2; 
    img = img(:, :) - averImg(:, :);
    
    for r = 1 : (imgRow)
        for c = 1 : (imgCol)
            img(r, c) = img(r, c) * 100 * exp(-abs(img(r, c)*filtParam));     
        end
    end    
    out = img;
end

