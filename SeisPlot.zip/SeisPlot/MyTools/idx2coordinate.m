function [ output_args ] = idx2coordinate( input_args )
%IDX2COORDINATE Summary of this function goes here
%   Detailed explanation goes here


end

