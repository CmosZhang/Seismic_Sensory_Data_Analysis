function [ix] = interpolation(x, y, stepx, stepy)
    [row, clo] = size(x);
    
    ix = ones(size(x));
    minx = min(x(:));
% ˮƽ�����ֵ
    for r = 1 : row
        idx = x(r, :)==minx;
        minxIdx = find(idx == 1);        
        for i = 2 : length(minxIdx)
            if(minxIdx(i) - minxIdx(i -1) <= stepx)
                ix(r, minxIdx(i-1) : minxIdx(i)) = y(r, minxIdx(i-1) : minxIdx(i)) ;
            end
        end
    end
    for c = 1 : clo
        idx = ix(:, c)==minx;
        minxIdx = find(idx == 1);        
        for i = 2 : length(minxIdx)
            if(minxIdx(i) - minxIdx(i -1) <= stepy)
                ix(minxIdx(i-1) : minxIdx(i), c) = y(minxIdx(i-1) : minxIdx(i), c);
            end
        end
    end
end


