function [KX, ctrs] = kmeansFault(X, ctrsCnt, classifyCategory)
     if nargin == 1 
        ctrsCnt = 2;
        classifyCategory = 2;
     elseif nargin == 2
        classifyCategory = 2;     
     end
    
    [idx,ctrs] = kmeans(X(:), ctrsCnt);

    idx = reshape(idx(:), size(X));
    
    KX = X;
    if classifyCategory == 2
        [~, maxIdx]= max(ctrs(:, 1));
        KX(idx ~= maxIdx) = 0;
        KX(idx == maxIdx) = 1;
    else 
        for i = 1 : ctrsCnt
            KX(idx == i) = ctrs(i, 1);
        end
    end
end

