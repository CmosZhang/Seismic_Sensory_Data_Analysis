function aux=l_litho_plot(wlog,varargin)  %#ok
% Function plots log curves with lithology indicated by markers and/or color
%
error('"l_litho_plot" has been replaced by l_lithoplot".')
