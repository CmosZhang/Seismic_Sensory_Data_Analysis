function mywarning(str)

alert(str) %#ok This is what I want!

